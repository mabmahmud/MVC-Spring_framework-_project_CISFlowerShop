package info.hccis.flowershop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CISFlowerShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CISFlowerShopApplication.class, args);
	}

}
