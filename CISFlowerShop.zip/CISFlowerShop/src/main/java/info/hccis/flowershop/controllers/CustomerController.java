package info.hccis.flowershop.controllers;

import info.hccis.flowershop.bo.CustomerTypeBO;
import info.hccis.flowershop.jpa.entity.Customer;
import info.hccis.flowershop.jpa.entity.CustomerType;
import info.hccis.flowershop.repositories.CustomerRepository;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;
import java.util.ResourceBundle;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controller for the camper functionality of the site
 *
 * @since 20200930
 * @author CIS2232
 */
@Controller
@RequestMapping("/customer")
public class CustomerController {

    private final CustomerRepository customerRepository;

    public CustomerController(CustomerRepository cr) {
        customerRepository = cr;
    }

    /**
     * Page to allow user to view campers
     *
     * @since 20200528
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/list")
    public String list(Model model) {

        //Go get the campers from the database.
        //Use the jpa repository to get the campers.

        model.addAttribute("customers", loadCustomers());
        model.addAttribute("findNameMessage", "Customer loaded");

        return "customer/list";
    }

    /**
     * Page to allow user to add a camper
     *
     * @since 20201002
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/add")
    public String add(Model model) {

        model.addAttribute("message", "Add a customer");

        Customer customer = new Customer();
        model.addAttribute("customer", customer);;

        return "customer/add";
    }

    /**
     * Page to allow user to submit the add a camper. It will put the camper in
     * the database.
     *
     * @since 20201002
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/addSubmit")
    public String addSubmit(Model model, @Valid @ModelAttribute("customer") Customer customer, BindingResult result) {

        //If errors put the object back in model and send back to the add page.
        if (result.hasErrors()) {
            System.out.println("Validation error");
            return "customer/add";
        }

        //Save that camper to the database
//        CamperBO camperBO = new CamperBO();
//        camperBO.save(camper);

        customerRepository.save(customer);

        String propFileName = "messages";
        ResourceBundle rb = ResourceBundle.getBundle(propFileName);
        String successAddString = rb.getString("message.customer.saved");

        model.addAttribute("message", successAddString);
        model.addAttribute("customers", loadCustomers());

        return "customer/list";

    }

    /**
     * Page to allow user to edit a camper
     *
     * @since 20201007
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/edit")
    public String edit(Model model, HttpServletRequest request) {

        String idString = (String) request.getParameter("id");
        int id = Integer.parseInt(idString);
        System.out.println("BJTEST - id=" + id);

//        //reload the list
//        
//        ArrayList<Camper> campers = (ArrayList<Camper>) camperRepository.findAll();
        //TODO use findOne here.,
        Optional<Customer> found = customerRepository.findById(id);
//        for (Camper current : campers) {
//            if (current.getId() == id) {
//                found = current;
//                break;
//            }
//        }

        model.addAttribute("customer", found);
        return "customer/add";
    }

    /**
     * Page to allow user to delete a camper
     *
     * @since 20201009
     * @author BJM
     */
    @RequestMapping("/delete")
    public String delete(Model model, HttpServletRequest request) {

        String idString = (String) request.getParameter("id");
        int id = Integer.parseInt(idString);
        System.out.println("BJTEST - id=" + id);

        String propFileName = "messages";
        ResourceBundle rb = ResourceBundle.getBundle(propFileName);
        String successString;
        try {
            customerRepository.deleteById(id);
            successString = rb.getString("message.customer.deleted") + " (" + id + ")";
        } catch (EmptyResultDataAccessException e) {
            successString = rb.getString("message.customer.deleted.error") + " (" + id + ")";
        }

        model.addAttribute("message", successString);
        model.addAttribute("customers", loadCustomers());

        return "customer/list";
    }

    public ArrayList<Customer> loadCustomers() {
        ArrayList<Customer> customers = (ArrayList<Customer>) customerRepository.findAll();
        HashMap<Integer, String> customerTypesMap = CustomerTypeBO.getCustomerTypesMap();
        for (Customer current : customers) {
            current.setCustomerTypeDescription(customerTypesMap.get(current.getCustomerTypeId()));
        }
        return customers;

    }

}
