package info.hccis.flowershop.controllers;

import info.hccis.flowershop.bo.CustomerTypeBO;
import info.hccis.flowershop.jpa.entity.Customer;
import info.hccis.flowershop.repositories.CustomerRepository;
import info.hccis.flowershop.repositories.CustomerTypeRepository;
import java.util.ArrayList;
import java.util.HashMap;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controller for the report functionality of the site
 *
 * @since 20201021
 * @author CIS2232
 */
@Controller
@RequestMapping("/report")
public class CustomerReportController {

    private final CustomerRepository customerRepository;
    private final CustomerTypeRepository customerTypeRepository;

    public CustomerReportController(CustomerRepository cr, CustomerTypeRepository ctr) {
        customerRepository = cr;
        customerTypeRepository = ctr;
    }
    
        /**
     * Page to allow user to specify birthday
     *
     * @since 20201021
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/name")
    public String getName(Model model) {

        Customer customer = new Customer();
        model.addAttribute("customer", customer);

        return "report/name";
    }

//    /**
//     * Page to allow user to view campers
//     *
//     * @since 20200528
//     * @author BJM (modified from Fred/Amro's project
//     */
//    @RequestMapping("/list")
//    public String list(Model model) {
//
//        //Go get the campers from the database.
//        //Use the jpa repository to get the campers.
//
//        model.addAttribute("campers", loadCampers());
//        model.addAttribute("findNameMessage", "Campers loaded");
//
//        return "camper/list";
//    }

    /**
     * Page to allow user to specify birthday
     *
     * @since 20201021
     * @author BJM (modified from Fred/Amro's project
     */
//    @RequestMapping("/name")
//    public String getBirthday(Model model) {
//
//        Camper camper = new Camper();
//        model.addAttribute("camper", camper);
//
//        return "report/birthday";
//    }

    /**
     * Page to allow user to submit the birthday report
     *
     * @since 20201021
     * @author BJM (modified from Fred/Amro's project
     */
    @RequestMapping("/submitName")
    public String addSubmit(Model model, @ModelAttribute("customer") Customer customer) {

        model.addAttribute("customers", loadCustomersByName(customer.getFullName()));
        return "customer/list";

    }

    public ArrayList<Customer> loadCustomersByName(String name) {
        ArrayList<Customer> customers = (ArrayList<Customer>) customerRepository.findAllByFullName(name);
        HashMap<Integer, String> customerTypesMap = CustomerTypeBO.getCustomerTypesMap();
        for (Customer current : customers) {
            current.setCustomerTypeDescription(customerTypesMap.get(current.getCustomerTypeId()));
        }
        return customers;

    }

}
