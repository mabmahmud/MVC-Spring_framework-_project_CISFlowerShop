/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.hccis.flowershop.fileio;

import com.google.gson.Gson;
import info.hccis.flowershop.jpa.entity.Customer;
import info.hccis.flowershop.util.CisUtility;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.stereotype.Service;


/**
 *
 * @author mrahman2
 */

@Service
public class CustomerIO {
    
    
    //public static final String FILE_PATH = "c:\\flowershop";
    
    /**
     * Save all customers to file as json format.Todo: Set up program to overload customers arraylist.
     *
     * @param customers
     * @throws java.io.IOException
     */
    public static void saveCustomer(ArrayList<Customer> customers) throws IOException{
        
        //Attempt to create directory
        
        String currentDate = CisUtility.getCurrentDate("yyyyMMddhhmmss");
        String fileName = "c:\\flowershop\\customer_" + currentDate + ".json";
        
        //String fileName = "c:\\fitness\\courts_" + currentDate + ".json";
        Path path = Paths.get(fileName);
        Files.createDirectories(path.getParent());
        FileWriter fw = null;
        BufferedWriter bw = null;

        try {

            fw = new FileWriter(fileName, true);
            bw = new BufferedWriter(fw);
            Gson gson = new Gson();
            String stringJson = "";
            for (Customer current : customers) {
                stringJson += gson.toJson(current) + System.lineSeparator();
            }
            fw.write(stringJson);
        } catch (IOException e) {
        } finally {
            try {
                if (bw != null) {
                    bw.close();
                }

                if (fw != null) {
                    fw.close();
                }

            } catch (IOException ex) {

                ex.printStackTrace();

            }
        }
        
        
        
//        Path path = Paths.get(FILE_PATH);
//        try {
//            Files.createDirectory(path.getParent());
//            
//        } catch (IOException ex) {
//            Logger.getLogger(CustomerIO.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        //Attempt to create file.
//       
//        file = new File(FILE_PATH );
//        Path customerPath = Paths.get(FILE_PATH );
//        try {
//            file.createNewFile();
//        } catch (FileAlreadyExistsException ex) {
//            Logger.getLogger(CustomerIO.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IOException ex) {
//            Logger.getLogger(CustomerIO.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        BufferedWriter writer = null;
//        
//        try {
//            writer = new BufferedWriter(new FileWriter(FILE_PATH, true));
//            
//            //Convert contents of arrayList to .json using foreach loop
//            for (Customer current: customers) {
//                try {
//                    Gson gson = new Gson();
//                    String customerJson = gson.toJson(current);
//                    
//                    writer.write(customerJson + System.lineSeparator());
//                } catch (IOException ex) {
//                        System.out.println("Error");
//                }
//            }
//            try {
//                writer.close();
//            }
//            catch (IOException ex) {
//                System.out.println("Writer couldn't be closed properly");
//            }
//        } catch (IOException ex) {
//            Logger.getLogger(CustomerIO.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

                        
}
