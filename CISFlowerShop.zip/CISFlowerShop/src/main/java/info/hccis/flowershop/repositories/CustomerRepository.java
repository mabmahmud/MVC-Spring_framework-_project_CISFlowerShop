package info.hccis.flowershop.repositories;

import info.hccis.flowershop.jpa.entity.Customer;
import info.hccis.flowershop.jpa.entity.FlowerOrder;
import java.util.ArrayList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Integer> {
    
   // ArrayList<Customer> findAllByFullName(String fullName);
    ArrayList<Customer> findAllByFullName(String fullName); 
    
   // ArrayList<FlowerOrder> findAllByMonth (String date);
    
    
}