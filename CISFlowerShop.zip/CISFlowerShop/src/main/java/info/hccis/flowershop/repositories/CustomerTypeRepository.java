package info.hccis.flowershop.repositories;

import info.hccis.flowershop.jpa.entity.CustomerType;
import java.util.ArrayList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerTypeRepository extends CrudRepository<CustomerType, Integer> {

    ArrayList<CustomerType> findAllById(String id);
    
    ArrayList<CustomerType> findAllByDescription(String name);
}
