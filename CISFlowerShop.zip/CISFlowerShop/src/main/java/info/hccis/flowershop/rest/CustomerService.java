
package info.hccis.flowershop.rest;

import com.google.gson.Gson;
import info.hccis.flowershop.jpa.entity.Customer;
import info.hccis.flowershop.repositories.CustomerRepository;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.Valid;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * 
 * @author mrahman2
 * @since 20201113
 */
@Path("/CustomerService/customers")
public class CustomerService {

    private final CustomerRepository cr;

    @Autowired
    public CustomerService(CustomerRepository cr) {
        this.cr = cr;

    }

    @GET
    @Produces("application/json")
    public ArrayList<Customer> getAll() {
        ArrayList<Customer> customers = (ArrayList<Customer>) cr.findAll();
        return customers;
    }

    @GET
    @Path("/{id}")
    @Produces("application/json")
    public Response getParkingPassById(@PathParam("id") int id) throws URISyntaxException {

        Optional<Customer> customers = cr.findById(id);

        if (!customers.isPresent()) {
            return Response.status(204).build();
        } else {
            return Response
                    .status(200)
                    .entity(customers).build();
        }
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createCustomer(String customerJson) 
    {
        
        Gson gson = new Gson();
        Customer customer = gson.fromJson(customerJson, Customer.class);
        
        if(customer.getFullName() == null || customer.getFullName().isEmpty()) {
            return Response.status(400).entity("Please provide all mandatory inputs").build();
        }
 
        if(customer.getId() == null){
            customer.setId(0);
        }

        customer = cr.save(customer);

        String temp = "";
        temp = gson.toJson(customer);

        return Response.status(201).entity(temp).header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT").build();        
    }
}

//
//@RestController
//@RequestMapping("/rest/parkingpass")
//public class ParkingPassService {
//
//    private final ParkingPassRepository pr;
//
//    @Autowired
//    public ParkingPassService(ParkingPassRepository pr) {
//        this.pr = pr;
//
//    }
//
//    @RequestMapping("/")
//    public ArrayList<ParkingPass> getAll() {
//        return (ArrayList<ParkingPass>) pr.findAll();
//    }
//
//    @RequestMapping("/{id}")
//    public ParkingPass getById(@PathVariable int id) {
//        return pr.findById(id).orElseGet(ParkingPass::new);
//    }
//
//    @RequestMapping("/addpass")
//    public ParkingPass addPass(@Valid @RequestBody ParkingPass parkingpass) {
//        if (parkingpass.getId() == null) {
//            parkingpass.setId(0);
//        }
//
//        return pr.save(parkingpass);
//    }
//}
